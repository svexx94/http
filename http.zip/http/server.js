// server.js
const express = require('express');
const app = express();

// Middleware для парсинга JSON и urlencoded
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Задание 1: базовый сервер / ответ "Hello, Express!"
app.get('/', (req, res) => {
  res.send('Hello, Express!');
});

// Задание 2: маршрут /user/:id
app.get('/user/:id', (req, res) => {
  res.json({ id: req.params.id });
});

// Задание 3: маршрут /book/:author/:title
app.get('/book/:author/:title', (req, res) => {
  const { author, title } = req.params;
  res.json({ author, title });
});

// Задание 4: маршрут /search с query-параметрами
app.get('/search', (req, res) => {
  const { q, limit } = req.query;
  res.json({ query: q, limit });
});

// Задание 5: POST /echo, возвращает JSON из тела запроса
app.post('/echo', (req, res) => {
  res.json(req.body);
});

// Задание 6: POST /form с urlencoded данными
app.post('/form', (req, res) => {
  const { name, age } = req.body;
  res.json({ name, age });
});

// Задание 7: маршруты /data для GET и POST
app.route('/data')
  .get((req, res) => {
    res.json({ method: 'GET' });
  })
  .post((req, res) => {
    res.json({ method: 'POST', body: req.body });
  });

// Задание 8: /check/:number, проверка четности
app.get('/check/:number', (req, res) => {
  const num = parseInt(req.params.number, 10);
  if (isNaN(num)) {
    res.json({ error: 'Invalid number' });
  } else {
    const result = num % 2 === 0 ? 'even' : 'odd';
    res.json({ result });
  }
});

// Задание 9: /analyze, анализ текста и чисел
app.post('/analyze', (req, res) => {
  const { text, numbers } = req.body;
  const length = text ? text.length : 0;
  const sum = Array.isArray(numbers) ? numbers.reduce((acc, n) => acc + n, 0) : 0;
  const average = Array.isArray(numbers) && numbers.length > 0
    ? sum / numbers.length
    : 0;
  res.json({ length, sum, average });
});

// Задание 10: /calc/:operation/:a/:b
app.get('/calc/:operation/:a/:b', (req, res) => {
  const { operation, a, b } = req.params;
  const numA = parseFloat(a);
  const numB = parseFloat(b);
  let result;

  if (isNaN(numA) || isNaN(numB)) {
    return res.json({ error: 'Invalid numbers' });
  }

  switch (operation) {
    case 'add':
      result = numA + numB;
      break;
    case 'sub':
      result = numA - numB;
      break;
    case 'mul':
      result = numA * numB;
      break;
    case 'div':
      if (numB === 0) {
        return res.json({ error: 'Division by zero' });
      }
      result = numA / numB;
      break;
    default:
      return res.json({ error: 'Unknown operation' });
  }

  res.json({ result });
});

// Запуск сервера на порту 3000
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});